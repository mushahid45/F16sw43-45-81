package com.example.zaidkorai.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.provider.CallLog;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Goto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goto);



    }
    public void callButton(View v){
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + "15"));
        startActivity(intent);

    }
public void galleryButton(View v){
    Intent i = new Intent(Intent.ACTION_VIEW);
    i.setData(Uri.parse("content://media/external/images/media/"));
    startActivity(i);

}
public void cameraButton(View v){
    Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
    startActivity(i);
}
public void dailpadButton(View v) {
    Intent intent = new Intent(Intent.ACTION_DIAL);
    intent.setData(Uri.parse("tel:0123456789"));
    startActivity(intent);
    }
public void contactButton(View v){
    Intent i = new Intent(Intent.ACTION_VIEW);
    i.setData(Uri.parse("content://contacts/people/"));
    startActivity(i);
}
public void browserButton(View v){
    Intent i = new Intent(Intent.ACTION_VIEW);
    i.setData(Uri.parse("http://www.google.com/"));
    startActivity(i);
}
public void calllogButton(View v){
    Intent showCallLog = new Intent();
    showCallLog.setAction(Intent.ACTION_VIEW);
    showCallLog.setType(CallLog.Calls.CONTENT_TYPE);
    startActivity(showCallLog);
}
}
