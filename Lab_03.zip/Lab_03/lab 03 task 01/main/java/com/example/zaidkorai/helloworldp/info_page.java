package com.example.zaidkorai.helloworldp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class info_page extends AppCompatActivity {
     TextView v1,v2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_page);
        v1 = findViewById(R.id.v1);
        v2 = findViewById(R.id.v2);
        Intent in = getIntent();
        String uname = in.getStringExtra("username");
        String email = in.getStringExtra("email");
        v1.setText(uname);
        v2.setText(email);
    }



}
