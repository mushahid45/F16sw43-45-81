package com.example.zaidkorai.helloworldp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class login extends AppCompatActivity {
      EditText e1, e2;
      Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        e1 = findViewById(R.id.e1);
        e2 = findViewById(R.id.e2);
        b = findViewById(R.id.b);
    }
    public void onClick(View v) {
       Intent in= getIntent();
       String username = in.getStringExtra("username").trim();
       String pass = in.getStringExtra("password").trim();
       String email = in.getStringExtra("email").trim();

        if(username.equals(e1.getText().toString().trim()) && pass .equals(e2.getText().toString().trim())) {
            Intent intent = new Intent(this, info_page.class);
            intent.putExtra("username", e1.getText().toString());
            intent.putExtra("email", email);
            intent.putExtra("password", e2.getText().toString());
            startActivity(intent);
        }

        }
    }


